# HW-4 Readme for YOUR_NAME

Please place your response to this week here.
